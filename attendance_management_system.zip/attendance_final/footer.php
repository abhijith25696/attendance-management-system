<!-- Footer
 * Author: Rakhi Dayanandan
-->

<link rel="stylesheet" href="style.css">
<div class="ft">

<h3> &copy 2019 </h3>

</div>

</body>

</html>